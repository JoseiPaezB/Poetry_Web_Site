package com.example.navigation_lazycolumn_starter.components
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CornerSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.navigation_lazycolumn_starter.model.Pokemon
import com.example.navigation_lazycolumn_starter.model.getPokemons


@Preview(showBackground = true)
@Composable
fun PokemonCard(
    pokemon: Pokemon = getPokemons()[0],
    aldarClick: (Pokemon) -> Unit = {}
) {
    Card(
        modifier = Modifier
            .padding(4.dp)
            .padding(top = 5.dp)
            .fillMaxWidth()
            .clickable { aldarClick(pokemon) },
        shape = RoundedCornerShape(corner = CornerSize(16.dp)),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Start
            ) {
                Surface(
                    modifier = Modifier
                        .padding(12.dp)
                        .size(100.dp) // Mantener el tamaño de la imagen
                        .clip(CircleShape) // Hacer la imagen redonda
                ) {
                    val image = pokemon.url
                    AsyncImage(
                        model = image,
                        contentDescription = "Pokemon Image",
                        contentScale = ContentScale.Crop // Asegurarte que la imagen cubra el área
                    )
                }
                Column(modifier = Modifier.padding(4.dp)) {
                    Text(text = pokemon.name, style = MaterialTheme.typography.headlineMedium)
                    Text(text = "+: ${pokemon.phone}", style = MaterialTheme.typography.bodyMedium)
                }
            }

            // Agregamos el IconButton al final de la fila
            IconButton(
                onClick = {
                    // Acción de llamada (puedes mostrar un mensaje o realizar alguna acción específica)
                }
            ) {
                Icon(
                    imageVector = Icons.Default.Phone, // Ícono de teléfono
                    contentDescription = "Call Icon",
                    tint = Color.Green
                )
            }
        }
    }
}
