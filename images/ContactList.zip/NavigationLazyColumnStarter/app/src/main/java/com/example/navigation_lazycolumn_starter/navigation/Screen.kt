package com.example.navigation_lazycolumn_starter.navigation

sealed class Screen (val route: String){
    object HomeScreen : Screen("Home")
    object DetailsScreen: Screen("Details")
}