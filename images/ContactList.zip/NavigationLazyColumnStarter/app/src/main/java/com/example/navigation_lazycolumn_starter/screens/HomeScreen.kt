package com.example.navigation_lazycolumn_starter.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.navigation_lazycolumn_starter.R
import com.example.navigation_lazycolumn_starter.components.PokemonCard
import com.example.navigation_lazycolumn_starter.model.getPokemons
import com.example.navigation_lazycolumn_starter.navigation.Screen
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip


@Composable
fun HomeScreen(navController: NavController) {
    Column {
        // Sección de información personal
        PersonalInfoSection()

        // Listado de Pokémons
        LazyColumn {
            items(items = getPokemons()) { pokemon ->
                PokemonCard(pokemon) {
                    navController.currentBackStackEntry?.savedStateHandle?.set("pokemonId", pokemon)
                    navController.navigate(Screen.DetailsScreen.route)
                }
            }
        }
    }
}

@Composable
fun PersonalInfoSection() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Box para contener la imagen en forma circular
        Box(
            modifier = Modifier
                .size(100.dp) // Tamaño del círculo
                .clip(CircleShape) // Hace la imagen circular
                .background(MaterialTheme.colorScheme.primary) // Fondo del círculo
                .border(2.dp, MaterialTheme.colorScheme.onPrimary, CircleShape), // Borde del círculo
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.img), // Cambia esto por tu imagen o ícono
                contentDescription = "User Icon",
                modifier = Modifier.size(80.dp), // Tamaño de la imagen dentro del círculo
                contentScale = ContentScale.Crop
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Información de usuario
        Text(text = "Usuario 1", style = MaterialTheme.typography.headlineMedium)
        Text(text = "Contact List", style = MaterialTheme.typography.headlineMedium)
        Text(text = "+3334179092", style = MaterialTheme.typography.bodyMedium)
    }
}


