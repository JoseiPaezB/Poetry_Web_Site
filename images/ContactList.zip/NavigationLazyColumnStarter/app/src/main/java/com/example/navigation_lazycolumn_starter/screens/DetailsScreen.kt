package com.example.navigation_lazycolumn_starter.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.navigation_lazycolumn_starter.model.Pokemon

@Composable
fun DetailsScreen(navController: NavController) {

    val pokemon = navController.previousBackStackEntry?.savedStateHandle?.get<Pokemon>("pokemonId")

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center // Centra el contenido dentro del Box
    ) {
        Column(
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (pokemon != null) {
                Text(pokemon.name, fontSize = 25.sp)
                Spacer(modifier = Modifier.padding(5.dp))

                // Imagen del Pokémon (circular)
                Surface(
                    modifier = Modifier
                        .size(100.dp) // Ajusta el tamaño según sea necesario
                        .padding(12.dp),
                    shape = CircleShape,
                    color = Color.LightGray // Color de fondo opcional
                ) {
                    AsyncImage(
                        model = pokemon.url,
                        contentDescription = "Pokemon Image",
                        contentScale = ContentScale.Crop // Crop para mantener la imagen circular
                    )
                }

                Spacer(modifier = Modifier.padding(5.dp))

                // Detalles de contacto
                Text("Name: " + pokemon.name)
                Text("Contact: +" + pokemon.phone)
                Text("Email: " + pokemon.name + "@gmail.com")
                Text("Edad: " + pokemon.hp)

                Spacer(modifier = Modifier.padding(10.dp))

                // Botón de opción de llamada (sin acción)
                Button(onClick = {
                    // No ejecuta ninguna acción, solo visual
                    // Puedes agregar alguna lógica futura si deseas
                }) {
                    Text("Call "+ pokemon.name)
                }
            }
        }
    }
}


