package com.example.navigation_lazycolumn_starter.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlin.random.Random


@Parcelize
data class Pokemon(
    val name: String,
    val url: String,
    val hp: String,
    val phone: String,
) : Parcelable



fun getPokemons(): List<Pokemon> {

    return listOf(
        Pokemon("Diana Chancay", "https://essa-africa.org/sites/default/files/2022-03/51131849887_d1c86f0e40_o_0.jpg", "45",
           "8133445566"),
        Pokemon("Joaquin Fiallo", "https://d1fufvy4xao6k9.cloudfront.net/images/blog/posts/2023/06/hock36.jpg", "39","3334179922"),
        Pokemon("Deba Emilio", "https://img.freepik.com/free-photo/smiley-man-relaxing-outdoors_23-2148739334.jpg", "40",
            "8181667710"),
        Pokemon("Setfano Dalia", "https://us.movember.com/uploads/images/resources/5df779f991cf99e6610bf01a9d93d70d5861282e-org.png", "44",
            "8190432388"),
        Pokemon("Agustin Monca", "https://assets.myntassets.com/dpr_1.5,q_60,w_400,c_limit,fl_progressive/assets/images/28219632/2024/3/12/2f53aaab-40e1-4c5b-8148-6ad150e5f4341710256687634CampusSutraMenClassicOpaqueCheckedCasualShirt2.jpg", "44",
            "8180006630"),
        Pokemon("Regina Yelna", "https://upload.wikimedia.org/wikipedia/commons/8/86/Woman_at_Lover%27s_Bridge_Tanjung_Sepat_%28cropped%29.jpg", "35",
            "819977345671"),
        Pokemon("Cecilia Armada", "https://thumbs.dreamstime.com/b/mujer-india-hermosa-21389017.jpg", "45",
            "8199917853")
    )
}

